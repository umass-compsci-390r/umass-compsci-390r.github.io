//gcc got_plt.c -o got_plt

#include <stdio.h>

int main() {
	char buf[64];
	fgets(buf, 63, stdin);
	printf("%s", buf);
}
