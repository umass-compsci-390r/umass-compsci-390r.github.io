//gcc write.c -o write

#include <stdio.h>

int write_to_me = 0;

int main() {
	char buf[64];
	printf("%p\n", &write_to_me);
	fgets(buf, 63, stdin);
	printf(buf);
	printf("\nWrite_To_Me: %d\n", write_to_me);
}
