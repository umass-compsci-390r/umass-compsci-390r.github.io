//gcc stack_leak.c -o stack_leak

#include <stdio.h>

int main() {
	long int a = 5;
	int b = 3;
	int c = 1;
	char user_buf[64];
	fgets(user_buf, 63, stdin);
	printf(user_buf);
}
