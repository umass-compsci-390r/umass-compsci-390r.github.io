//gcc echo.c -o echo

#include <stdio.h>

int main() {
	printf("I'll echo whatever you send me \n>>");
	char buf[256];
	fgets(buf, 255, stdin);
	printf(buf);
}

