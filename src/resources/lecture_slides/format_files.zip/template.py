from pwn import *

p = process()

gdb.debug(p, gdbscript=f'''
        break *main
''')

payload = b""

p.sendline(payload)

p.interactive()
