#include <stdio.h>
#include <stdlib.h>

int main() {
	int *ptr[30];
	for (int i = 0; i < 26; i++) {
		ptr[i] = malloc(5000);
	}

	ptr[26] = malloc(5000);

    ptr[27] = malloc(999999);

	//for (int i = 13; i > 0; i--) {
	//	free(ptr[i]);
	//}
}
