#include <stdio.h>
#include <stdlib.h>

int main() {
	int *ptr[4];

	for (int i = 0; i < 4; i++) {
		ptr[i] = malloc(16);
	}
	for (int i = 0; i < 4; i++) {
		free(ptr[i]);
	}
	malloc(16);
	malloc(16);
	malloc(16);
	malloc(16);
}
