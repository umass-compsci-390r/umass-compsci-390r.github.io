#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Books {
    char title[16];
    char author[16];
	int  id;
};

struct Books *books[8];

int main() {
	books[0] = malloc(sizeof(struct Books));
	books[1] = malloc(sizeof(struct Books));

	if(books[0] != NULL) {
		strcpy(books[0]->title, "Cool Title");
		strcpy(books[0]->author, "Bobby Bob");
		books[0]->id = 431;
	}
	if(books[1] != NULL) {
		strcpy(books[1]->title, "Great Title");
		strcpy(books[1]->author, "Not Bobby");
		books[1]->id = 905;
	}
	free(books[0]);
	free(books[1]);
	return 0;
}
