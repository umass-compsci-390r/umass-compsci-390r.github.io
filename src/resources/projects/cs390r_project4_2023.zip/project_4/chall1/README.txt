Your goal in this challenge is to get the flag. Source code for this challenge is provided. You will
need to make use of the got/plt to leak out libc before being able to spawn a shell once you figure
out how to trigger the buffer overflow.

Grading Criteria:
		25% - Find a way to bypass/leak the Canary
		25% - Trigger a buffer overflow by using the special item
		25% - Leak a libc address
		25% - Get the flag
        
