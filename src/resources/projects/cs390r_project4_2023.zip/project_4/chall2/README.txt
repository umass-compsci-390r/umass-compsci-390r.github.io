Your goal in this challenge is to get the flag. The vulnerability is a simple
heap logic bug that does not require any complicated exploitation techniques.
Source code for this challenge is provided.

Grading Criteria:
        20% - Get a leak to bypass pie randomizations
		30% - Trigger a memory corruption that results in non-intended behavior
		50% - Get the flag

