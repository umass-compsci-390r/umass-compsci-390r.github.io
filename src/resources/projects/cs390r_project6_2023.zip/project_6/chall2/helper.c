#include <stdio.h>
#include <stdlib.h>

void hello(char *func_name) {
    printf("Hello from: %s\n", func_name);
}
