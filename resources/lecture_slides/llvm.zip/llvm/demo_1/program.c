#include <stdio.h>

int f(int x) {
    int a = x - 3;
    int b = 0;

    if (a > 2) {
        b = 3;
    } else {
        b = 5;
    }

    return b;
}

int main() {
    printf("Hello from main %d\n", f(3));

    return 0;
}
