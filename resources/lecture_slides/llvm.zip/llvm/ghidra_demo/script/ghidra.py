# @category 390R

from ghidra.program.model.symbol import SourceType

for func in currentProgram.getFunctionManager().getFunctions(True):
    print("[+] " + str(func.getSignature()) + " @ " + str(func.getEntryPoint()))
    if (func.getName() == "f"):
        func.setName("New_Name", SourceType.ANALYSIS)
