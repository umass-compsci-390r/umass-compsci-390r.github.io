# @category 390R

print("Hello World")
