#include <stdio.h>

int main() {
    int x = 3;
    int y = 2;
    int sum = 0;

    if ((x + 3) > y) {
        x += 2;
    } else {
        for (int i = 0; i < y; i++) {
            sum += x;
            x+=1;
        }
    }

    printf("X is now %d\n", x);
    return sum;
}
