#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Constants.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"

using namespace llvm;

/// Anonymous namespace to separate this module from rest of llvm
namespace {

/// This method does the actual work of this pass.
/// It is called on every module that is hit during compilation
void visitor(Module &mod) {
    std::vector<Instruction *> dels;

    // Loop through all functions/blocks/instructions in this module
    for (auto &func : mod) {
        for (auto &block : func) {
            for (auto &instr : block) {
                // Look for a subtract `BinaryOperator` instruction
                if (auto *op = dyn_cast<BinaryOperator>(&instr)) { 
                    if (op->getOpcode() != BinaryOperator::Sub) {
                        continue;
                    }

                    // Initialize a builder to create a new instruction at this location
                    IRBuilder<> builder(op);

                    // Create new instruction with same lhs and rhs of previous instruction
                    Value *lhs  = op->getOperand(0);
                    Value *rhs  = op->getOperand(1);
                    Value *add  = builder.CreateNSWAdd(lhs, rhs);

                    // Loop through all uses of the previous `sub` instruction, and replace them 
                    // with uses to the new `add` instruction
                    for (auto& U : op->uses()) {
                        User* user = U.getUser();
                        user->setOperand(U.getOperandNo(), add);
                    }

                    // Mark the previous, now unused, sub instruction for deletion after the loop
                    // We cannot immediately delete it because otherwise the block-iterator would 
                    // break
                    dels.push_back(op);
                }
            }
        }
    }

    // Finally delete all invalidated sub operations
    for (auto &I : dels) {
        I->eraseFromParent();
    }
}

struct analysis_pass : PassInfoMixin<analysis_pass> {
    /// Main entry point
    /// This defines that this pass should be run on every module (instead of eg. every
    /// individual function or every block). It also indicates if this pass invalidated any other
    /// passes or modified the code using the return value
    PreservedAnalyses run(Module &M, ModuleAnalysisManager &) {
        visitor(M);
        return PreservedAnalyses::none();
    }

    /// Call this plugin on every module, otherwise it will be skipped for functions with the
    /// `optnone` attribute
    static bool isRequired() { return true; }
};
} // End anonymous namespace

/// Register this plugin
llvm::PassPluginLibraryInfo get_analysis_pass_plugin_info() {
    return {LLVM_PLUGIN_API_VERSION, "analysis_pass", LLVM_VERSION_STRING, [](PassBuilder &PB) {
        PB.registerPipelineParsingCallback (
                [](StringRef Name, ModulePassManager &FPM,
                ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "analysis_pass") {
                        FPM.addPass(analysis_pass());
                        return true;
                    }
                    return false;
                }
            );
        }
    };
}

/// This lets `opt` find and call this plugin
extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
    return get_analysis_pass_plugin_info();
}

