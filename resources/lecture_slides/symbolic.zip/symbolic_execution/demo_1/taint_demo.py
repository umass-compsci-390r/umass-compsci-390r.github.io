import os

from triton import *
from pwn import *

# Directory that contains the memory/register dumps
# Generated using snapshot.py
DUMP_DIR = "./dump/"

# Return address of function `f`
F_RET_ADDR = 0x401158

# Setup
"""
gdb taint_demo
b *f
run
source ../snapshot.py
fulldump

python3 taint_demo.py
"""

# Loads a memory/register dump from disk into ctx
def loadDump(ctx):
    reg_file = DUMP_DIR + "regs"
    mem_file = DUMP_DIR + "memory_maps"

    # Load registers from dump into ctx
    with open(reg_file) as f:
        regs = eval(f.read())

        ctx.setConcreteRegisterValue(ctx.registers.rax,    regs['rax'])
        ctx.setConcreteRegisterValue(ctx.registers.rbx,    regs['rbx'])
        ctx.setConcreteRegisterValue(ctx.registers.rcx,    regs['rcx'])
        ctx.setConcreteRegisterValue(ctx.registers.rdx,    regs['rdx'])
        ctx.setConcreteRegisterValue(ctx.registers.rdi,    regs['rdi'])
        ctx.setConcreteRegisterValue(ctx.registers.rsi,    regs['rsi'])
        ctx.setConcreteRegisterValue(ctx.registers.rbp,    regs['rbp'])
        ctx.setConcreteRegisterValue(ctx.registers.rsp,    regs['rsp'])
        ctx.setConcreteRegisterValue(ctx.registers.rip,    regs['rip'])
        ctx.setConcreteRegisterValue(ctx.registers.r8,     regs['r8'])
        ctx.setConcreteRegisterValue(ctx.registers.r9,     regs['r9'])
        ctx.setConcreteRegisterValue(ctx.registers.r10,    regs['r10'])
        ctx.setConcreteRegisterValue(ctx.registers.r11,    regs['r11'])
        ctx.setConcreteRegisterValue(ctx.registers.r12,    regs['r12'])
        ctx.setConcreteRegisterValue(ctx.registers.r13,    regs['r13'])
        ctx.setConcreteRegisterValue(ctx.registers.r14,    regs['r14'])
        ctx.setConcreteRegisterValue(ctx.registers.eflags, regs['eflags'])
        ctx.setConcreteRegisterValue(ctx.registers.cs,     regs['cs'])
        ctx.setConcreteRegisterValue(ctx.registers.ss,     regs['ss'])
        ctx.setConcreteRegisterValue(ctx.registers.ds,     regs['ds'])
        ctx.setConcreteRegisterValue(ctx.registers.es,     regs['es'])
        ctx.setConcreteRegisterValue(ctx.registers.fs,     regs['fs'])
        ctx.setConcreteRegisterValue(ctx.registers.gs,     regs['gs'])

    # Load memory from dump into ctx
    with open(mem_file) as f:
        mem_mappings = eval(f.read())

        for i in range(0, len(mem_mappings)):
            data_file = DUMP_DIR + "raw_memory/" + f"raw_{i}"
            start = mem_mappings[i]['start']
            size  = mem_mappings[i]['size']

            # Get the raw byte backing
            with open(data_file, 'rb') as df:
                data = df.read()
                assert(len(data) == size)
                ctx.setConcreteMemoryAreaValue(start, data)

def emulate(ctx, pc):
    while pc:
        opcodes = ctx.getConcreteMemoryAreaValue(pc, 16)

        instruction = Instruction(pc, opcodes)
        ctx.processing(instruction)

        print(f"{instruction} : {instruction.isTainted()}")

        if pc == F_RET_ADDR:
            print("[+] Function `f` return reached")
            if ctx.isRegisterTainted(ctx.registers.rax):
                print("[+] Return value tainted")
            return 


        pc = ctx.getConcreteRegisterValue(ctx.registers.rip)

def main():
    ctx = TritonContext(ARCH.X86_64)

    # Define symbolic optimizations
    ctx.setMode(MODE.ALIGNED_MEMORY, True)
    ctx.setMode(MODE.CONSTANT_FOLDING, True)
    ctx.setMode(MODE.AST_OPTIMIZATIONS, True)

    loadDump(ctx)

    ctx.taintRegister(ctx.registers.edi)

    emulate(ctx, ctx.getConcreteRegisterValue(ctx.registers.rip))

if __name__ == '__main__':
    main()
