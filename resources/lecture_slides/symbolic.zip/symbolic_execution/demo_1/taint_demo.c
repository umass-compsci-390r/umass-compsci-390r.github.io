#include <stdlib.h>

// gcc taint_demo.c -o taint_demo -g -no-pie -static

int f(int x) {
    int z = 0;

    if (x > 5) {
        z = x;
    }

    return z;
}

int main() {
    int a = f(8);
    exit(a);
}
