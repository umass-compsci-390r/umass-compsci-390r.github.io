int f(int x, int y) {
    char buf[0x8];

    if (x != 0) {
        if (y > 2) {
            gets(buf);
        } else {
            exit(1);
        }
    } else {
        puts("Invalid");
    }
}
