import os
import sys

from triton import *
from pwn import *

# Directory that contains the memory/register dumps
# Generated using snapshot.py
DUMP_DIR = "./dump/"

# These are the 2 points that we do not want to hit
F_FAIL_ADDR_1 = 0x40112e
F_FAIL_ADDR_2 = 0x401127

# These are the "goal" addresses we want to find
F_GOAL_ADDR_1 = 0x40111a
F_GOAL_ADDR_2 = 0x401120

# Setup
"""
gdb demo
b *f
run
source ../snapshot.py
fulldump

python3 demo.py
"""

def emulate(ctx, pc):
    while pc:
        opcodes = ctx.getConcreteMemoryAreaValue(pc, 16)

        instruction = Instruction(pc, opcodes)

        ctx.processing(instruction)

        if pc == F_FAIL_ADDR_1 or pc == F_FAIL_ADDR_2:
            print("Failed to find a solution")
            return 

        if pc == F_GOAL_ADDR_2:
            print(f"Reached goal with model: {ctx.getModel(ctx.getPathPredicate())}")
            return 

        # `je` instruction jumps if zf is set. We don't want this jump to be executed so we
        # add a path constraint for zf to be set to 0
        if instruction.getAddress() == 0x401114:
            zf = ctx.getSymbolicRegister(ctx.registers.zf).getAst()

            # Add constraint
            ctx.pushPathConstraint(zf == 0)

            # Retrieve a model that satisfies the added constraints
            model = ctx.getModel(ctx.getPathPredicate())

            # Set concrete values for the symbolic variable now that we have an answer that passes
            # the model
            for k, v in model.items():
                ctx.setConcreteVariableValue(ctx.getSymbolicVariable(v.getId()), v.getValue())

        # `jbe` instruction jumps if (zf == 1 OR cf == 1). We don't want this jump to happen so we
        # add path constraints so that both are unset
        if instruction.getAddress() == 0x40111a:
            zf = ctx.getSymbolicRegister(ctx.registers.zf).getAst()
            cf = ctx.getSymbolicRegister(ctx.registers.cf).getAst()

            # Add constraints
            ctx.pushPathConstraint(zf == 0)
            ctx.pushPathConstraint(cf == 0)

            # Retrieve a model that satisfies the added constraints
            model = ctx.getModel(ctx.getPathPredicate())

            # Set concrete values for the symbolic variable now that we have an answer that passes
            # the model
            for k, v in model.items():
                ctx.setConcreteVariableValue(ctx.getSymbolicVariable(v.getId()), v.getValue())

        pc = ctx.getConcreteRegisterValue(ctx.registers.rip)

# Set the arguments to `f` as symbolic variables
def symbolize_input(ctx):
    ctx.symbolizeRegister(ctx.registers.rdi, "rdi")
    ctx.symbolizeRegister(ctx.registers.rsi, "rsi") 

# Loads a memory/register dump from disk into ctx
def loadDump(ctx):
    reg_file = DUMP_DIR + "regs"
    mem_file = DUMP_DIR + "memory_maps"

    # Load registers from dump into ctx
    with open(reg_file) as f:
        regs = eval(f.read())

        ctx.setConcreteRegisterValue(ctx.registers.rax,    regs['rax'])
        ctx.setConcreteRegisterValue(ctx.registers.rbx,    regs['rbx'])
        ctx.setConcreteRegisterValue(ctx.registers.rcx,    regs['rcx'])
        ctx.setConcreteRegisterValue(ctx.registers.rdx,    regs['rdx'])
        ctx.setConcreteRegisterValue(ctx.registers.rdi,    regs['rdi'])
        ctx.setConcreteRegisterValue(ctx.registers.rsi,    regs['rsi'])
        ctx.setConcreteRegisterValue(ctx.registers.rbp,    regs['rbp'])
        ctx.setConcreteRegisterValue(ctx.registers.rsp,    regs['rsp'])
        ctx.setConcreteRegisterValue(ctx.registers.rip,    regs['rip'])
        ctx.setConcreteRegisterValue(ctx.registers.r8,     regs['r8'])
        ctx.setConcreteRegisterValue(ctx.registers.r9,     regs['r9'])
        ctx.setConcreteRegisterValue(ctx.registers.r10,    regs['r10'])
        ctx.setConcreteRegisterValue(ctx.registers.r11,    regs['r11'])
        ctx.setConcreteRegisterValue(ctx.registers.r12,    regs['r12'])
        ctx.setConcreteRegisterValue(ctx.registers.r13,    regs['r13'])
        ctx.setConcreteRegisterValue(ctx.registers.r14,    regs['r14'])
        ctx.setConcreteRegisterValue(ctx.registers.eflags, regs['eflags'])
        ctx.setConcreteRegisterValue(ctx.registers.cs,     regs['cs'])
        ctx.setConcreteRegisterValue(ctx.registers.ss,     regs['ss'])
        ctx.setConcreteRegisterValue(ctx.registers.ds,     regs['ds'])
        ctx.setConcreteRegisterValue(ctx.registers.es,     regs['es'])
        ctx.setConcreteRegisterValue(ctx.registers.fs,     regs['fs'])
        ctx.setConcreteRegisterValue(ctx.registers.gs,     regs['gs'])

    # Load memory from dump into ctx
    with open(mem_file) as f:
        mem_mappings = eval(f.read())

        for i in range(0, len(mem_mappings)):
            data_file = DUMP_DIR + "raw_memory/" + f"raw_{i}"
            start = mem_mappings[i]['start']
            size  = mem_mappings[i]['size']

            # Get the raw byte backing
            with open(data_file, 'rb') as df:
                data = df.read()
                assert(len(data) == size)
                ctx.setConcreteMemoryAreaValue(start, data)



def main():
    ctx = TritonContext(ARCH.X86_64)

    # Define symbolic optimizations
    ctx.setMode(MODE.ALIGNED_MEMORY, True)
    ctx.setMode(MODE.CONSTANT_FOLDING, True)
    ctx.setMode(MODE.AST_OPTIMIZATIONS, True)

    loadDump(ctx)

    symbolize_input(ctx)

    emulate(ctx, ctx.getConcreteRegisterValue(ctx.registers.rip))

if __name__ == '__main__':
    main()
