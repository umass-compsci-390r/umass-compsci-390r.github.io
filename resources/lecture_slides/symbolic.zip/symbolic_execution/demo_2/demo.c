// gcc demo.c -o demo -g -no-pie

int f(unsigned int x, unsigned int y) {
    if (x != 0) {
        if (y > 2) {
            // This is the goal
            return 0;
        } else {
            return 1;
        }
    } else {
        return 2;
    }
}

int main() {
    f(0, 0);
}
