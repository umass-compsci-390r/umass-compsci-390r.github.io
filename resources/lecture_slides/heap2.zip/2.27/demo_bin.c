#include <stdio.h>
#include <stdlib.h>

struct Data {
    char *buffer;
    int size;
};

struct Data data[0x10];
int count = 0;

void print_menu() {
    printf("[1] Allocate Chunk\n");
    printf("[2] Free Chunk\n");
    printf("[3] Edit Chunk\n");
    printf("[4] Exit\n\n");
    printf(">> ");
}

void leak() {
    int *leak = (int*) malloc(24);
    printf("Heap @ %p\n", leak);
    printf("Puts @ %p\n\n", &puts);
}

void allocate_chunk() {
    long size;
    char buf[0x20];

    printf("Size?\n>> ");
	if (fgets(buf, sizeof(buf), stdin) == NULL) { exit(-1); }
    size = strtol(buf, NULL, 0);

    data[count].buffer = malloc(size);
    data->size = size;

    count++;
}

void free_chunk() {
    int index;
    char buf[0x20];

    printf("Index?\n>> ");
	if (fgets(buf, sizeof(buf), stdin) == NULL) { exit(-1); }
    index = atoi(buf);

    if (index < count) {
        free(data[index].buffer);
    } else {
        printf("No chunk allocated at this index\n");
    }
}

void edit_chunk() {
    int index;
    char buf[0x20];

    printf("Index?\n>> ");
	if (fgets(buf, sizeof(buf), stdin) == NULL) { exit(-1); }
    index = atoi(buf);

    if (index < count) {
        printf("Data?\n>> ");
        fgets(data[index].buffer, 0x40, stdin);
    } else {
        printf("No chunk allocated at this index\n");
    }
}


int main() {
    int choice = -1;
    char buf[0x20];

    leak();

    while(1) {
        print_menu();
	    if (fgets(buf, sizeof(buf), stdin) == NULL) { exit(-1); }
        choice = atoi(buf);

        switch (choice) {
            case 1:
                allocate_chunk();
                break;
            case 2:
                free_chunk();
                break;
            case 3:
                edit_chunk();
                break;
            case 4:
                exit(1);
            default:
                printf("Not a valid option\n");
        }
    }
}
