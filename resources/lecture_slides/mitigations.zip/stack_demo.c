//No Protections
//gcc stack_demo.c -o stack_demo -fno-stack-protector -z execstack -no-pie
//No Canary
//gcc stack_demo.c -o stack_demo -no-pie -fno-stack-protector
//All Protections
//gcc stack_demo.c -o stack_demo
#include <stdio.h>
#include <stdlib.h>

int main() {
	char buf[8];
	printf("%p\n", buf);
	gets(buf);
	return;
}
