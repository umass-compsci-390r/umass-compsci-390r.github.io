//gcc rop_puts.c -o rop_puts -fno-stack-protector
#include <stdio.h>

void gadgets() {
	__asm__("pop %rdi\n\t"
        "ret\n\t");
}

int main() {
	char buf[8];
	puts("Calling puts\n");
	printf("%p\n", &main);
	gets(buf);
}
